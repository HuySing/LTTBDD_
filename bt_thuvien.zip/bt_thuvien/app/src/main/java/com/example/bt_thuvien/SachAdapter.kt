package com.example.bt_thuvien

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.TextView

class SachAdapter(
    private val context: Context,
    private val data: List<String>
) : BaseAdapter() {

    override fun getCount(): Int = data.size

    override fun getItem(position: Int): Any = data[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_sach, parent, false)

        val chkSach = view.findViewById<CheckBox>(R.id.chkSach)
        val tvTenSach = view.findViewById<TextView>(R.id.tvTenSach)

        tvTenSach.text = data[position]
        chkSach.isChecked = true

        return view
    }
}
