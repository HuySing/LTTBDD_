package com.example.bt_thuvien

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class QuanLyFragment : Fragment() {

    private lateinit var edtSinhVien: EditText
    private lateinit var btnThayDoi: Button
    private lateinit var btnThem: Button
    private lateinit var lvSach: ListView
    private lateinit var tvEmpty: TextView

    private lateinit var adapter: SachAdapter
    private val displayedBooks = mutableListOf<String>()
    private var currentSinhVien: String = ""

    companion object {
        fun newInstance(sinhVien: String): QuanLyFragment {
            val fragment = QuanLyFragment()
            val args = Bundle()
            args.putString("sinhvien", sinhVien)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentSinhVien = arguments?.getString("sinhvien") ?: MainActivity.danhSachSinhVien.first()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_quanly, container, false)

        edtSinhVien = view.findViewById(R.id.edtSinhVien)
        btnThayDoi = view.findViewById(R.id.btnThayDoi)
        btnThem = view.findViewById(R.id.btnThem)
        lvSach = view.findViewById(R.id.lvSach)
        tvEmpty = view.findViewById(R.id.txtThongBao)

        adapter = SachAdapter(requireContext(), displayedBooks)
        lvSach.adapter = adapter


        edtSinhVien.setText(currentSinhVien)
        loadBooksFor(currentSinhVien)

        btnThayDoi.setOnClickListener {
            val name = edtSinhVien.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(requireContext(), "Vui lòng nhập tên!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!MainActivity.danhSachSinhVien.contains(name)) {
                Toast.makeText(requireContext(), "Tên không đúng, vui lòng nhập lại!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            (activity as? MainActivity)?.setCurrentStudent(name)
            loadBooksFor(name)
        }

        btnThem.setOnClickListener {
            val name = edtSinhVien.text.toString().trim()
            (activity as? MainActivity)?.openFragment(BookListFragment.newInstance(name))
        }

        return view
    }

    private fun loadBooksFor(name: String) {
        displayedBooks.clear()
        val books = MainActivity.studentBooks[name] ?: mutableListOf()
        displayedBooks.addAll(books)
        adapter.notifyDataSetChanged()

        if (displayedBooks.isEmpty()) {
            tvEmpty.text = "Bạn chưa mượn quyển sách nào\nNhấn 'Thêm' để bắt đầu hành trình đọc sách!"
            tvEmpty.visibility = View.VISIBLE
            lvSach.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            lvSach.visibility = View.VISIBLE
        }
    }
}
