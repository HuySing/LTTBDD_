package com.example.bt_thuvien

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class BookListFragment : Fragment() {

    private var tenSinhVien: String = ""
    private lateinit var lvAllBooks: ListView
    private lateinit var btnXong: Button

    private val allBooks = listOf("Sách 01", "Sách 02", "Sách 03", "Sách 04", "Sách 05","Sách 06", "Sách 07", "Sách 08")

    companion object {
        fun newInstance(sinhVien: String): BookListFragment {
            val fragment = BookListFragment()
            val args = Bundle()
            args.putString("sinhvien", sinhVien)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tenSinhVien = arguments?.getString("sinhvien") ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_book_list, container, false)

        lvAllBooks = view.findViewById(R.id.lvAllBooks)
        btnXong = view.findViewById(R.id.btnXong)

        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_multiple_choice, allBooks)
        lvAllBooks.adapter = adapter
        lvAllBooks.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        btnXong.setOnClickListener {
            val checkedIds = lvAllBooks.checkedItemPositions
            val studentBookList = MainActivity.studentBooks.getOrPut(tenSinhVien) { mutableListOf() }

            for (i in 0 until allBooks.size) {
                if (checkedIds.get(i)) {
                    val book = allBooks[i]
                    if (!studentBookList.contains(book)) {
                        studentBookList.add(book)
                    }
                }
            }

            Toast.makeText(requireContext(), "Đã thêm sách vào $tenSinhVien", Toast.LENGTH_SHORT).show()
            (activity as? MainActivity)?.openFragment(QuanLyFragment.newInstance(tenSinhVien))
        }

        return view
    }
}
