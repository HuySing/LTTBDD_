package com.example.bt_thuvien

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class StudentFragment : Fragment() {

    private lateinit var edtTenMoi: EditText
    private lateinit var btnThemMoi: Button
    private lateinit var lvSinhVien: ListView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_student, container, false)

        edtTenMoi = view.findViewById(R.id.edtTenSV)
        btnThemMoi = view.findViewById(R.id.btnThemSV)
        lvSinhVien = view.findViewById(R.id.lvSinhVien)

        adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, MainActivity.danhSachSinhVien)
        lvSinhVien.adapter = adapter

        btnThemMoi.setOnClickListener {
            val name = edtTenMoi.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(requireContext(), "Nhập tên sinh viên!", Toast.LENGTH_SHORT).show()
            } else {
                (activity as? MainActivity)?.addStudent(name)
                adapter.notifyDataSetChanged()
                Toast.makeText(requireContext(), "Đã thêm sinh viên mới!", Toast.LENGTH_SHORT).show()
                edtTenMoi.setText("")
            }
        }

        return view
    }
}
