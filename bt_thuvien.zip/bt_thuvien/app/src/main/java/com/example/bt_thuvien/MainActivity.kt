package com.example.bt_thuvien

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    companion object {
        val danhSachSinhVien = mutableListOf("Nguyễn Văn A", "Trần Thị B")
        val studentBooks = mutableMapOf<String, MutableList<String>>()
    }

    private lateinit var bottomNav: BottomNavigationView
    private var currentSinhVien: String = danhSachSinhVien.first()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNav = findViewById(R.id.bottomNavigationView)

        openFragment(QuanLyFragment.newInstance(currentSinhVien))

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_quanly -> openFragment(QuanLyFragment.newInstance(currentSinhVien))
                R.id.menu_sv -> openFragment(StudentFragment())
                R.id.menu_sach -> openFragment(BookListFragment.newInstance(currentSinhVien))
            }
            true
        }
    }

    fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun addStudent(name: String) {
        if (!danhSachSinhVien.contains(name)) {
            danhSachSinhVien.add(name)
            studentBooks[name] = mutableListOf()
        }
    }

    fun setCurrentStudent(name: String) {
        currentSinhVien = name
    }
}
